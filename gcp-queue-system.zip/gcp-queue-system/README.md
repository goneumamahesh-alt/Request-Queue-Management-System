# GCP Async Queue System

A production-ready, priority-based async task queue system built on Google Cloud Platform.

## Architecture

```
Client
  │
  ▼
┌─────────────────────────────────────────┐
│            Cloud Run — API              │
│  POST /enqueue   GET /status/:id        │
│  POST /schedule  GET /metrics           │
│  GET  /dead-letter                      │
└───────────────┬─────────────────────────┘
                │  Creates tasks
                ▼
┌───────────────────────────────────────────────────┐
│              Cloud Tasks                          │
│  ┌──────────────────┐  maxDispatch: 100/s         │
│  │ high_priority_q  │  maxConcurrent: 50          │
│  ├──────────────────┤                             │
│  │ medium_priority_q│  maxDispatch: 50/s          │
│  ├──────────────────┤                             │
│  │ low_priority_q   │  maxDispatch: 20/s          │
│  ├──────────────────┤                             │
│  │ dead_letter_q    │  manual review only         │
│  └──────────────────┘                             │
└───────────────┬───────────────────────────────────┘
                │  HTTP push (OIDC auth)
                ▼
┌─────────────────────────────────────────┐
│        Cloud Functions — Worker         │
│                                         │
│  handlers: email, sms, webhook,         │
│  data_processing, report_generation,    │
│  image_resize                           │
│                                         │
│  Auto-retry (5xx → Cloud Tasks retries) │
│  DLQ after maxRetries exhausted         │
└───────────────┬─────────────────────────┘
                │  Writes metadata + logs
                ▼
┌────────────────────────────────────────────┐
│              Firestore                     │
│  collections/tasks         (metadata)      │
│  collections/dead_letter_queue             │
│  collections/scheduled_tasks               │
│  collections/metrics       (counters)      │
└────────────────────────────────────────────┘
                ▲
                │  Reads + exports
┌───────────────┴─────────────────────────┐
│   Cloud Scheduler → Metrics Function    │
│   Writes to Cloud Monitoring (custom    │
│   metrics) + emits CRITICAL log alerts  │
└─────────────────────────────────────────┘
```

## Folder Structure

```
gcp-queue-system/
├── api/
│   └── index.js          # Express API (Cloud Run)
├── worker/
│   ├── index.js          # Cloud Function entry point
│   └── handlers.js       # Per-taskType business logic
├── scheduler/
│   └── index.js          # Delayed + cron task scheduling
├── monitoring/
│   ├── logger.js         # Structured JSON logger (Cloud Logging)
│   └── metrics.js        # Metrics snapshot + Cloud Monitoring export
├── config/
│   ├── constants.js      # Shared config + queue names
│   └── queues.yaml       # Cloud Tasks queue definitions
├── tests/
│   └── queue.test.js     # Jest unit + integration tests
├── scripts/
│   └── deploy.sh         # One-command GCP deployment
├── package.json
└── README.md
```

## Quick Start

### Prerequisites
- Node.js 20+
- Google Cloud SDK (`gcloud`) authenticated
- A GCP project with billing enabled

### Local Development
```bash
npm install
PORT=8080 npm start
```

### Deploy to GCP
```bash
chmod +x scripts/deploy.sh
GCP_PROJECT_ID=my-project ./scripts/deploy.sh
```

### Run Tests
```bash
npm test
```

---

## API Reference

### POST /enqueue
Add a task to a priority queue.

**Request body:**
```json
{
  "taskType": "email",
  "priority": "high",
  "payload": {
    "to": "user@example.com",
    "subject": "Welcome",
    "body": "Thanks for signing up!"
  },
  "maxRetries": 3,
  "idempotencyKey": "optional-unique-key"
}
```

**taskType values:** `email` | `sms` | `webhook` | `data_processing` | `report_generation` | `image_resize`

**priority values:** `high` | `medium` | `low`

**Response 201 (queued):**
```json
{
  "taskId": "a1b2c3d4-...",
  "status": "queued",
  "priority": "high",
  "gcpTaskName": "projects/p/locations/l/queues/q/tasks/t"
}
```

**Response 202 (overflow → dead letter):**
```json
{
  "queued": false,
  "dead_letter": true,
  "taskId": "a1b2c3d4-..."
}
```

---

### POST /schedule
Schedule a task to run in the future.

```json
{
  "taskType": "report_generation",
  "priority": "low",
  "payload": { "reportType": "monthly" },
  "scheduleDelaySeconds": 3600
}
```

---

### GET /status/:taskId
Get current state of a task.

**Response:**
```json
{
  "taskType": "email",
  "priority": "high",
  "status": "completed",
  "attempt": 0,
  "result": { "sent": true, "messageId": "msg_123" },
  "createdAt": "...",
  "completedAt": "..."
}
```

**status values:** `pending` | `processing` | `completed` | `retrying` | `failed` | `dead_letter`

---

### GET /metrics
Live queue metrics snapshot.

---

### GET /dead-letter?limit=50
List overflow/failed tasks in the dead letter queue.

---

### POST /dead-letter/:taskId/requeue
Manually requeue a dead-letter task.

---

## curl Examples

```bash
BASE=https://queue-api-xxxxxxxx-uc.a.run.app

# Enqueue an email (high priority)
curl -X POST $BASE/enqueue \
  -H "Content-Type: application/json" \
  -d '{"taskType":"email","priority":"high","payload":{"to":"a@b.com","subject":"Hi","body":"Hello"}}'

# Enqueue a webhook (medium)
curl -X POST $BASE/enqueue \
  -H "Content-Type: application/json" \
  -d '{"taskType":"webhook","priority":"medium","payload":{"url":"https://httpbin.org/post","method":"POST","body":{"event":"signup"}}}'

# Schedule a report 1 hour from now
curl -X POST $BASE/schedule \
  -H "Content-Type: application/json" \
  -d '{"taskType":"report_generation","priority":"low","payload":{"reportType":"weekly"},"scheduleDelaySeconds":3600}'

# Check task status
curl $BASE/status/a1b2c3d4-0000-0000-0000-000000000000

# View metrics
curl $BASE/metrics

# List dead letter queue
curl "$BASE/dead-letter?limit=10"

# Requeue a dead letter task
curl -X POST $BASE/dead-letter/a1b2c3d4-0000-0000-0000-000000000000/requeue
```

---

## Queue Configuration

| Queue | Max Dispatch/s | Max Concurrent | Max Retries | Backoff |
|-------|---------------|----------------|-------------|---------|
| high_priority_queue | 100 | 50 | 5 | 5s → 120s |
| medium_priority_queue | 50 | 25 | 5 | 10s → 300s |
| low_priority_queue | 20 | 10 | 3 | 30s → 600s |
| dead_letter_queue | 5 | 2 | 1 | manual |

**Overflow thresholds (soft limit tracked in Firestore):**

| Priority | Max size before DLQ |
|----------|---------------------|
| high | 500 |
| medium | 1000 |
| low | 2000 |

---

## Retry Strategy

1. Worker throws → returns HTTP 5xx
2. Cloud Tasks applies exponential backoff and re-delivers
3. On `gcpRetryCount >= maxRetries` worker returns HTTP 200 (stops Cloud Tasks retrying) and writes to Firestore `dead_letter_queue`
4. Alert fires when DLQ > 100 items
5. Manual requeue via `POST /dead-letter/:id/requeue`

---

## Monitoring & Alerts

Custom Cloud Monitoring metrics written every minute:

- `custom.googleapis.com/queue/queue_depth_high`
- `custom.googleapis.com/queue/queue_depth_medium`
- `custom.googleapis.com/queue/queue_depth_low`
- `custom.googleapis.com/queue/dead_letter_size`
- `custom.googleapis.com/queue/total_enqueued`
- `custom.googleapis.com/queue/total_success`
- `custom.googleapis.com/queue/total_retry`
- `custom.googleapis.com/queue/total_dead_letter`

Set alerting policies in Cloud Monitoring on these metrics for PagerDuty/Slack notifications.

---

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `GCP_PROJECT_ID` | ✅ | GCP project ID |
| `GCP_LOCATION` | ✅ | GCP region (e.g. `us-central1`) |
| `SERVICE_URL` | ✅ | Base URL of this API (Cloud Run URL) |
| `WORKER_SERVICE_ACCOUNT` | ✅ | SA email for OIDC worker auth |
| `SCHEDULER_SERVICE_ACCOUNT` | ✅ | SA email for Cloud Scheduler |
| `LOG_LEVEL` | ❌ | `debug`/`info`/`warn`/`error` (default: `info`) |
| `PORT` | ❌ | HTTP port (default: `8080`) |
