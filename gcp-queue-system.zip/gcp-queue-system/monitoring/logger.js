/**
 * Structured Logger
 *
 * Writes JSON logs compatible with Google Cloud Logging.
 * Uses the standard severity levels Cloud Logging understands:
 *   DEBUG, INFO, NOTICE, WARNING, ERROR, CRITICAL, ALERT, EMERGENCY
 */

"use strict";

const { LOG_LEVEL } = require("../config/constants");

const LEVELS = { debug: 0, info: 1, notice: 2, warn: 3, error: 4, critical: 5 };
const currentLevel = LEVELS[LOG_LEVEL] ?? LEVELS.info;

function log(severity, message, meta = {}) {
  if (LEVELS[severity.toLowerCase()] < currentLevel) return;

  const entry = {
    severity: severity.toUpperCase(),
    message,
    timestamp: new Date().toISOString(),
    ...meta,
  };

  // Cloud Logging parses JSON from stdout automatically
  process.stdout.write(JSON.stringify(entry) + "\n");
}

module.exports = {
  debug:    (msg, meta) => log("debug",    msg, meta),
  info:     (msg, meta) => log("info",     msg, meta),
  notice:   (msg, meta) => log("notice",   msg, meta),
  warn:     (msg, meta) => log("warning",  msg, meta),
  error:    (msg, meta) => log("error",    msg, meta),
  critical: (msg, meta) => log("critical", msg, meta),
};
