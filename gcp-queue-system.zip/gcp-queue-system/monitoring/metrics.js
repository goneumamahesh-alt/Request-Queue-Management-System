/**
 * Monitoring Module
 *
 * - metricsSnapshot()  → aggregates live data from Firestore for a dashboard
 * - alertOnThreshold() → emits CRITICAL logs (picked up by Cloud Monitoring alerts)
 * - exportToCloudMonitoring() → writes custom metrics via the Monitoring API
 */

"use strict";

const { Firestore } = require("@google-cloud/firestore");
const { MetricServiceClient } = require("@google-cloud/monitoring");
const logger = require("./logger");
const { PROJECT_ID, QUEUES, MAX_QUEUE_SIZE } = require("../config/constants");

const firestore = new Firestore();
const monitoringClient = new MetricServiceClient();

// ─── Snapshot all queue metrics ───────────────────────────────────────────────
async function metricsSnapshot() {
  const collections = ["enqueue", "processing", "overflow"];
  const docs = await Promise.all(
    collections.map((c) => firestore.collection("metrics").doc(c).get())
  );

  const [enqueue, processing, overflow] = docs.map((d) => (d.exists ? d.data() : {}));

  // Live queue depths
  const depths = {};
  for (const priority of ["high", "medium", "low"]) {
    const snap = await firestore
      .collection("tasks")
      .where("priority", "==", priority)
      .where("status", "in", ["pending", "processing"])
      .count()
      .get();
    depths[priority] = snap.data().count;
  }

  const dlqSize = await firestore
    .collection("dead_letter_queue")
    .where("status", "==", "dead_letter")
    .count()
    .get();

  const snapshot = {
    collectedAt: new Date().toISOString(),
    enqueue,
    processing,
    overflow,
    queueDepths: depths,
    deadLetterQueueSize: dlqSize.data().count,
  };

  await alertOnThreshold(snapshot);
  return snapshot;
}

// ─── Alert if queues are unhealthy ────────────────────────────────────────────
async function alertOnThreshold(snapshot) {
  for (const priority of ["high", "medium", "low"]) {
    const depth = snapshot.queueDepths[priority] || 0;
    const max   = MAX_QUEUE_SIZE[priority.toUpperCase()];
    const pct   = (depth / max) * 100;

    if (pct >= 90) {
      logger.critical(`Queue ${priority} is at ${pct.toFixed(1)}% capacity`, {
        priority,
        depth,
        max,
        alert: "queue_near_capacity",
      });
    } else if (pct >= 75) {
      logger.warn(`Queue ${priority} is at ${pct.toFixed(1)}% capacity`, { priority, depth, max });
    }
  }

  if (snapshot.deadLetterQueueSize > 100) {
    logger.critical("Dead letter queue exceeds 100 items — manual review required", {
      dlqSize: snapshot.deadLetterQueueSize,
      alert: "dlq_high",
    });
  }
}

// ─── Write custom metric to Cloud Monitoring ──────────────────────────────────
async function exportToCloudMonitoring(metricType, value, labels = {}) {
  const projectName = `projects/${PROJECT_ID}`;
  const now = new Date();

  const timeSeriesData = {
    metric: {
      type: `custom.googleapis.com/queue/${metricType}`,
      labels,
    },
    resource: { type: "global", labels: { project_id: PROJECT_ID } },
    points: [
      {
        interval: {
          endTime: { seconds: Math.floor(now.getTime() / 1000) },
        },
        value: { int64Value: value },
      },
    ],
  };

  try {
    await monitoringClient.createTimeSeries({
      name: projectName,
      timeSeries: [timeSeriesData],
    });
  } catch (err) {
    // Non-fatal — monitoring export failure shouldn't kill the main flow
    logger.warn("Failed to export metric to Cloud Monitoring", { metricType, error: err.message });
  }
}

// ─── Cloud Function: scheduled metrics export (every minute via Cloud Scheduler)
exports.metricsExport = async (_req, res) => {
  try {
    const snapshot = await metricsSnapshot();

    await Promise.all([
      exportToCloudMonitoring("queue_depth_high",   snapshot.queueDepths.high),
      exportToCloudMonitoring("queue_depth_medium", snapshot.queueDepths.medium),
      exportToCloudMonitoring("queue_depth_low",    snapshot.queueDepths.low),
      exportToCloudMonitoring("dead_letter_size",   snapshot.deadLetterQueueSize),
      exportToCloudMonitoring("total_enqueued",     snapshot.enqueue?.total || 0),
      exportToCloudMonitoring("total_success",      snapshot.processing?.success || 0),
      exportToCloudMonitoring("total_retry",        snapshot.processing?.retry || 0),
      exportToCloudMonitoring("total_dead_letter",  snapshot.processing?.dead_letter || 0),
    ]);

    logger.info("Metrics exported to Cloud Monitoring", { snapshot });
    if (res) res.status(200).json({ ok: true, snapshot });
  } catch (err) {
    logger.error("Metrics export failed", { error: err.message });
    if (res) res.status(500).json({ error: err.message });
  }
};

module.exports.metricsSnapshot = metricsSnapshot;
