/**
 * Task Handlers
 * One exported async function per taskType.
 * Each receives (payload, context) and must return a result object or throw.
 */

"use strict";

const logger = require("../monitoring/logger");

// ─── email ────────────────────────────────────────────────────────────────────
async function email(payload, ctx) {
  const { to, subject, body, templateId } = payload;
  if (!to || !subject) throw new Error("email handler: 'to' and 'subject' are required");

  logger.info("Sending email", { taskId: ctx.taskId, to, subject });

  // TODO: replace with real SendGrid / Mailgun / SES call
  await simulateWork(200);

  return { sent: true, to, subject, messageId: `msg_${Date.now()}` };
}

// ─── sms ──────────────────────────────────────────────────────────────────────
async function sms(payload, ctx) {
  const { to, message } = payload;
  if (!to || !message) throw new Error("sms handler: 'to' and 'message' are required");

  logger.info("Sending SMS", { taskId: ctx.taskId, to });

  // TODO: replace with real Twilio / SNS call
  await simulateWork(150);

  return { sent: true, to, sid: `SM${Date.now()}` };
}

// ─── webhook ──────────────────────────────────────────────────────────────────
async function webhook(payload, ctx) {
  const { url, method = "POST", headers = {}, body } = payload;
  if (!url) throw new Error("webhook handler: 'url' is required");

  logger.info("Dispatching webhook", { taskId: ctx.taskId, url, method });

  const fetch = (await import("node-fetch")).default;
  const response = await fetch(url, {
    method,
    headers: { "Content-Type": "application/json", ...headers },
    body: body ? JSON.stringify(body) : undefined,
    timeout: 10000,
  });

  if (!response.ok) {
    throw new Error(`Webhook responded with HTTP ${response.status}`);
  }

  return { delivered: true, url, statusCode: response.status };
}

// ─── data_processing ─────────────────────────────────────────────────────────
async function data_processing(payload, ctx) {
  const { datasetId, operation, params = {} } = payload;
  if (!datasetId || !operation) throw new Error("data_processing: 'datasetId' and 'operation' are required");

  logger.info("Running data processing job", { taskId: ctx.taskId, datasetId, operation });

  // Simulate a heavier workload
  await simulateWork(500);

  return { processed: true, datasetId, operation, rowsAffected: Math.floor(Math.random() * 10000) };
}

// ─── report_generation ───────────────────────────────────────────────────────
async function report_generation(payload, ctx) {
  const { reportType, dateRange, format = "pdf", recipientEmail } = payload;
  if (!reportType) throw new Error("report_generation: 'reportType' is required");

  logger.info("Generating report", { taskId: ctx.taskId, reportType, format });

  await simulateWork(800);

  return {
    generated: true,
    reportType,
    format,
    url: `gs://my-bucket/reports/${ctx.taskId}.${format}`,
    notifiedEmail: recipientEmail || null,
  };
}

// ─── image_resize ─────────────────────────────────────────────────────────────
async function image_resize(payload, ctx) {
  const { sourceUrl, widths = [640, 1280], format = "webp" } = payload;
  if (!sourceUrl) throw new Error("image_resize: 'sourceUrl' is required");

  logger.info("Resizing image", { taskId: ctx.taskId, sourceUrl, widths });

  await simulateWork(300);

  const variants = widths.map((w) => ({
    width: w,
    url: `gs://my-bucket/images/${ctx.taskId}_${w}.${format}`,
  }));

  return { resized: true, sourceUrl, variants };
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function simulateWork(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

module.exports = { email, sms, webhook, data_processing, report_generation, image_resize };
