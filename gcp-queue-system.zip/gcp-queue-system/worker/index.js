/**
 * GCP Cloud Function — Task Worker
 * Receives Cloud Tasks HTTP push events, processes jobs, handles retries.
 */

"use strict";

const { Firestore } = require("@google-cloud/firestore");
const logger = require("../monitoring/logger");
const handlers = require("./handlers");
const { MAX_RETRIES_DEFAULT } = require("../config/constants");

const firestore = new Firestore();

// ─── Main Cloud Function entrypoint ───────────────────────────────────────────
exports.processTask = async (req, res) => {
  // Cloud Tasks sets X-CloudTasks-TaskName and X-CloudTasks-TaskRetryCount headers
  const gcpTaskName = req.headers["x-cloudtasks-taskname"] || "unknown";
  const gcpRetryCount = parseInt(req.headers["x-cloudtasks-taskretrycount"] || "0", 10);
  const gcpQueueName = req.headers["x-cloudtasks-queuename"] || "unknown";

  let taskId, taskType, payload, maxRetries, attempt;

  try {
    ({ taskId, taskType, payload, maxRetries = MAX_RETRIES_DEFAULT, attempt = 0 } = req.body);

    if (!taskId || !taskType) {
      logger.error("Worker received malformed task body", { body: req.body });
      // Return 200 to prevent Cloud Tasks from endlessly retrying a bad payload
      return res.status(200).json({ error: "Malformed task — discarded" });
    }
  } catch (err) {
    logger.error("Failed to parse task body", { error: err.message });
    return res.status(200).json({ error: "Parse error — discarded" });
  }

  const logCtx = { taskId, taskType, gcpTaskName, gcpQueueName, attempt: gcpRetryCount };
  logger.info("Worker picked up task", logCtx);

  // ── Mark task as processing ───────────────────────────────────────────────
  await updateTaskStatus(taskId, "processing", { attempt: gcpRetryCount, startedAt: new Date().toISOString() });

  const startMs = Date.now();

  try {
    // ── Route to the right handler ────────────────────────────────────────
    const handler = handlers[taskType];
    if (!handler) {
      throw new Error(`Unknown taskType: "${taskType}"`);
    }

    const result = await handler(payload, { taskId, attempt: gcpRetryCount });
    const durationMs = Date.now() - startMs;

    // ── Success path ──────────────────────────────────────────────────────
    await updateTaskStatus(taskId, "completed", {
      result,
      completedAt: new Date().toISOString(),
      durationMs,
    });

    await bumpMetric("processing", "success", gcpQueueName);
    logger.info("Task completed successfully", { ...logCtx, durationMs });

    return res.status(200).json({ taskId, status: "completed", durationMs });

  } catch (err) {
    const durationMs = Date.now() - startMs;
    const isRetryable = gcpRetryCount < maxRetries;

    logger.error("Task processing failed", {
      ...logCtx,
      error: err.message,
      stack: err.stack,
      durationMs,
      willRetry: isRetryable,
    });

    if (isRetryable) {
      // ── Retry path: return 5xx so Cloud Tasks re-enqueues ────────────────
      await updateTaskStatus(taskId, "retrying", {
        lastError: err.message,
        attempt: gcpRetryCount,
        nextAttempt: gcpRetryCount + 1,
      });
      await bumpMetric("processing", "retry", gcpQueueName);
      return res.status(500).json({ taskId, status: "retry", error: err.message });

    } else {
      // ── Exhausted retries → dead letter ──────────────────────────────────
      await updateTaskStatus(taskId, "failed", {
        lastError: err.message,
        failedAt: new Date().toISOString(),
        durationMs,
      });
      await sendToDeadLetter(taskId, { taskType, payload, error: err.message, attempts: gcpRetryCount });
      await bumpMetric("processing", "dead_letter", gcpQueueName);

      // Return 200 so Cloud Tasks stops retrying (we handle it ourselves)
      return res.status(200).json({ taskId, status: "dead_letter", error: err.message });
    }
  }
};

// ─── Utility: update task doc in Firestore ────────────────────────────────────
async function updateTaskStatus(taskId, status, extra = {}) {
  try {
    await firestore.collection("tasks").doc(taskId).update({
      status,
      updatedAt: Firestore.FieldValue.serverTimestamp(),
      ...extra,
    });
  } catch (err) {
    logger.warn("Could not update task status in Firestore", { taskId, status, error: err.message });
  }
}

// ─── Utility: write to dead_letter_queue collection ──────────────────────────
async function sendToDeadLetter(taskId, data) {
  await firestore.collection("dead_letter_queue").doc(taskId).set(
    {
      ...data,
      status: "dead_letter",
      reason: "max_retries_exceeded",
      movedAt: Firestore.FieldValue.serverTimestamp(),
    },
    { merge: true }
  );
}

// ─── Utility: increment a monitoring metric ───────────────────────────────────
async function bumpMetric(collection, field, queue) {
  await firestore
    .collection("metrics")
    .doc(collection)
    .set(
      {
        [field]: Firestore.FieldValue.increment(1),
        [`by_queue.${queue}.${field}`]: Firestore.FieldValue.increment(1),
        lastUpdatedAt: Firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
}
