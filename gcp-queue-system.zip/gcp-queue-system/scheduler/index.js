/**
 * Scheduler Module
 *
 * Provides:
 *  - scheduleDelayed()  → one-shot future task via Cloud Tasks scheduleTime
 *  - setupCronJobs()    → registers Cloud Scheduler jobs (cron) that call /enqueue
 *  - listScheduled()    → lists pending scheduled tasks from Firestore
 */

"use strict";

const { CloudSchedulerClient } = require("@google-cloud/scheduler");
const { Firestore } = require("@google-cloud/firestore");
const { v4: uuidv4 } = require("uuid");
const logger = require("../monitoring/logger");
const { PROJECT_ID, LOCATION, SERVICE_URL } = require("../config/constants");

const schedulerClient = new CloudSchedulerClient();
const firestore = new Firestore();
const parent = `projects/${PROJECT_ID}/locations/${LOCATION}`;

// ─── Schedule a one-shot delayed task ────────────────────────────────────────
/**
 * @param {object} opts
 * @param {string} opts.taskType
 * @param {string} opts.priority
 * @param {object} opts.payload
 * @param {Date|number} opts.runAt  Date object or Unix timestamp (ms)
 * @param {number} [opts.maxRetries]
 */
async function scheduleDelayed({ taskType, priority, payload, runAt, maxRetries = 3 }) {
  const taskId = uuidv4();
  const runAtDate = runAt instanceof Date ? runAt : new Date(runAt);
  const nowMs = Date.now();

  if (runAtDate.getTime() <= nowMs) {
    throw new Error("scheduleDelayed: runAt must be in the future");
  }

  const delaySeconds = Math.floor((runAtDate.getTime() - nowMs) / 1000);

  // Record the scheduled intent in Firestore
  await firestore.collection("scheduled_tasks").doc(taskId).set({
    taskType,
    priority,
    payload,
    maxRetries,
    scheduledFor: runAtDate.toISOString(),
    status: "scheduled",
    createdAt: Firestore.FieldValue.serverTimestamp(),
  });

  logger.info("Task scheduled for future delivery", {
    taskId,
    taskType,
    priority,
    scheduledFor: runAtDate.toISOString(),
    delaySeconds,
  });

  // The actual Cloud Task is created by the API's /enqueue endpoint with scheduleDelaySeconds
  return {
    taskId,
    scheduledFor: runAtDate.toISOString(),
    delaySeconds,
    // Caller should POST to /enqueue with scheduleDelaySeconds: delaySeconds
    hint: `POST /enqueue with scheduleDelaySeconds: ${delaySeconds}`,
  };
}

// ─── Register Cloud Scheduler (cron) jobs ─────────────────────────────────────
/**
 * Creates or updates a Cloud Scheduler job that periodically calls /enqueue.
 *
 * @param {object} opts
 * @param {string} opts.name           Short identifier, e.g. "daily-report"
 * @param {string} opts.schedule       Cron expression, e.g. "0 9 * * 1-5"
 * @param {string} opts.timeZone       e.g. "America/New_York"
 * @param {string} opts.taskType
 * @param {string} opts.priority
 * @param {object} opts.payload
 */
async function registerCronJob({ name, schedule, timeZone = "UTC", taskType, priority, payload }) {
  const jobName = `${parent}/jobs/cron-${name}`;
  const body = JSON.stringify({ taskType, priority, payload });

  const jobDef = {
    name: jobName,
    schedule,
    timeZone,
    httpTarget: {
      uri: `${SERVICE_URL}/enqueue`,
      httpMethod: "POST",
      headers: { "Content-Type": "application/json" },
      body: Buffer.from(body),
      oidcToken: { serviceAccountEmail: process.env.SCHEDULER_SERVICE_ACCOUNT },
    },
    retryConfig: { retryCount: 3 },
  };

  try {
    // Try to update first; create if it doesn't exist
    const [existing] = await schedulerClient.getJob({ name: jobName }).catch(() => [null]);
    if (existing) {
      const [updated] = await schedulerClient.updateJob({ job: jobDef, updateMask: { paths: ["schedule", "http_target", "time_zone"] } });
      logger.info("Cron job updated", { name, schedule });
      return updated;
    } else {
      const [created] = await schedulerClient.createJob({ parent, job: jobDef });
      logger.info("Cron job created", { name, schedule });
      return created;
    }
  } catch (err) {
    logger.error("Failed to register cron job", { name, error: err.message });
    throw err;
  }
}

// ─── List pending scheduled tasks ─────────────────────────────────────────────
async function listScheduled(limit = 50) {
  const snapshot = await firestore
    .collection("scheduled_tasks")
    .where("status", "==", "scheduled")
    .orderBy("scheduledFor", "asc")
    .limit(limit)
    .get();

  return snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
}

// ─── Pre-built cron registrations (call once at startup/deploy) ───────────────
async function setupDefaultCronJobs() {
  const jobs = [
    {
      name: "daily-report",
      schedule: "0 7 * * 1-5",         // Weekdays at 07:00 UTC
      timeZone: "UTC",
      taskType: "report_generation",
      priority: "low",
      payload: { reportType: "daily_summary", format: "pdf" },
    },
    {
      name: "health-check-webhook",
      schedule: "*/5 * * * *",          // Every 5 minutes
      timeZone: "UTC",
      taskType: "webhook",
      priority: "high",
      payload: { url: `${SERVICE_URL}/health`, method: "GET" },
    },
  ];

  for (const job of jobs) {
    await registerCronJob(job);
  }

  logger.info("Default cron jobs registered", { count: jobs.length });
}

module.exports = { scheduleDelayed, registerCronJob, setupDefaultCronJobs, listScheduled };
