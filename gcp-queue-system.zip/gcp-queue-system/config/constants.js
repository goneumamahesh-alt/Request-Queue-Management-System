/**
 * Shared constants — referenced by API, worker, scheduler, and monitoring.
 */

"use strict";

const PROJECT_ID  = process.env.GCP_PROJECT_ID  || "my-gcp-project";
const LOCATION    = process.env.GCP_LOCATION     || "us-central1";
const SERVICE_URL = process.env.SERVICE_URL      || "https://queue-api-xxxxxxxx-uc.a.run.app";

// ── Cloud Tasks queue names (must match queues.yaml) ─────────────────────────
const QUEUES = {
  HIGH:   "high_priority_queue",
  MEDIUM: "medium_priority_queue",
  LOW:    "low_priority_queue",
  DLQ:    "dead_letter_queue",
};

// ── Per-priority soft max before overflow kicks in ────────────────────────────
const MAX_QUEUE_SIZE = {
  HIGH:   500,
  MEDIUM: 1000,
  LOW:    2000,
};

const MAX_RETRIES_DEFAULT = 3;

// ── Retry backoff configuration (seconds) ─────────────────────────────────────
const RETRY_CONFIG = {
  minBackoffSeconds:    10,
  maxBackoffSeconds:   600,
  maxDoublings:          5,
};

// ── Logging levels ─────────────────────────────────────────────────────────────
const LOG_LEVEL = process.env.LOG_LEVEL || "info";

module.exports = {
  PROJECT_ID,
  LOCATION,
  SERVICE_URL,
  QUEUES,
  MAX_QUEUE_SIZE,
  MAX_RETRIES_DEFAULT,
  RETRY_CONFIG,
  LOG_LEVEL,
};
