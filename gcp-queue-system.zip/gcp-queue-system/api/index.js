/**
 * GCP Async Queue System — API Layer
 * Handles /enqueue, /schedule, /status, /metrics endpoints
 */

"use strict";

const express = require("express");
const { CloudTasksClient } = require("@google-cloud/tasks");
const { Firestore } = require("@google-cloud/firestore");
const { v4: uuidv4 } = require("uuid");
const Joi = require("joi");
const logger = require("../monitoring/logger");
const { QUEUES, PROJECT_ID, LOCATION, MAX_QUEUE_SIZE, SERVICE_URL } = require("../config/constants");

const app = express();
app.use(express.json());

const tasksClient = new CloudTasksClient();
const firestore = new Firestore();

// ─── Request Validation Schema ────────────────────────────────────────────────
const enqueueSchema = Joi.object({
  taskType: Joi.string().valid("email", "sms", "webhook", "data_processing", "report_generation", "image_resize").required(),
  priority: Joi.string().valid("high", "medium", "low").default("medium"),
  payload: Joi.object().required(),
  scheduleDelaySeconds: Joi.number().integer().min(0).max(2592000).optional(), // max 30 days
  maxRetries: Joi.number().integer().min(0).max(10).default(3),
  idempotencyKey: Joi.string().optional(),
});

// ─── Helpers ─────────────────────────────────────────────────────────────────

/**
 * Returns the fully-qualified Cloud Tasks queue path for a given priority.
 */
function getQueuePath(priority) {
  const queueName = QUEUES[priority.toUpperCase()];
  return tasksClient.queuePath(PROJECT_ID, LOCATION, queueName);
}

/**
 * Checks how many tasks are currently pending in Firestore for a queue.
 */
async function getQueueSize(priority) {
  const snapshot = await firestore
    .collection("tasks")
    .where("priority", "==", priority)
    .where("status", "in", ["pending", "processing"])
    .count()
    .get();
  return snapshot.data().count;
}

/**
 * Persists task metadata to Firestore.
 */
async function persistTask(taskId, data) {
  await firestore.collection("tasks").doc(taskId).set({
    ...data,
    createdAt: Firestore.FieldValue.serverTimestamp(),
    updatedAt: Firestore.FieldValue.serverTimestamp(),
  });
}

/**
 * Routes overflow tasks to the dead-letter queue and logs them.
 */
async function handleOverflow(taskId, taskData) {
  logger.warn("Queue overflow — routing to dead_letter_queue", { taskId, priority: taskData.priority });

  const dlqRef = firestore.collection("dead_letter_queue").doc(taskId);
  await dlqRef.set({
    ...taskData,
    overflowAt: Firestore.FieldValue.serverTimestamp(),
    reason: "queue_overflow",
    status: "dead_letter",
  });

  await firestore.collection("metrics").doc("overflow").set(
    { count: Firestore.FieldValue.increment(1), lastOverflowAt: Firestore.FieldValue.serverTimestamp() },
    { merge: true }
  );

  return { queued: false, dead_letter: true, taskId };
}

// ─── POST /enqueue ────────────────────────────────────────────────────────────
app.post("/enqueue", async (req, res) => {
  const { error, value } = enqueueSchema.validate(req.body);
  if (error) {
    return res.status(400).json({ error: error.details[0].message });
  }

  const { taskType, priority, payload, scheduleDelaySeconds, maxRetries, idempotencyKey } = value;
  const taskId = idempotencyKey || uuidv4();

  try {
    // ── Idempotency check ──────────────────────────────────────────────────
    if (idempotencyKey) {
      const existing = await firestore.collection("tasks").doc(taskId).get();
      if (existing.exists) {
        logger.info("Duplicate task rejected via idempotency key", { taskId });
        return res.status(200).json({ taskId, status: "already_queued", idempotent: true });
      }
    }

    // ── Overflow check ────────────────────────────────────────────────────
    const currentSize = await getQueueSize(priority);
    if (currentSize >= MAX_QUEUE_SIZE[priority.toUpperCase()]) {
      const result = await handleOverflow(taskId, { taskType, priority, payload, maxRetries });
      return res.status(202).json(result);
    }

    // ── Build Cloud Tasks payload ─────────────────────────────────────────
    const taskBody = JSON.stringify({ taskId, taskType, payload, maxRetries, attempt: 0 });
    const taskDef = {
      httpRequest: {
        httpMethod: "POST",
        url: `${SERVICE_URL}/worker/process`,
        headers: { "Content-Type": "application/json" },
        body: Buffer.from(taskBody).toString("base64"),
        oidcToken: { serviceAccountEmail: process.env.WORKER_SERVICE_ACCOUNT },
      },
    };

    // ── Schedule delay ────────────────────────────────────────────────────
    if (scheduleDelaySeconds && scheduleDelaySeconds > 0) {
      const scheduleTime = Math.floor(Date.now() / 1000) + scheduleDelaySeconds;
      taskDef.scheduleTime = { seconds: scheduleTime };
    }

    const queuePath = getQueuePath(priority);
    const [createdTask] = await tasksClient.createTask({ parent: queuePath, task: taskDef });

    // ── Persist metadata ──────────────────────────────────────────────────
    await persistTask(taskId, {
      taskType,
      priority,
      payload,
      maxRetries,
      attempt: 0,
      status: "pending",
      gcpTaskName: createdTask.name,
      scheduledFor: scheduleDelaySeconds
        ? new Date(Date.now() + scheduleDelaySeconds * 1000).toISOString()
        : null,
    });

    await firestore.collection("metrics").doc("enqueue").set(
      {
        total: Firestore.FieldValue.increment(1),
        [`by_priority.${priority}`]: Firestore.FieldValue.increment(1),
        lastEnqueueAt: Firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );

    logger.info("Task enqueued successfully", { taskId, taskType, priority, gcpTask: createdTask.name });
    return res.status(201).json({ taskId, status: "queued", priority, gcpTaskName: createdTask.name });

  } catch (err) {
    logger.error("Failed to enqueue task", { taskId, error: err.message, stack: err.stack });
    return res.status(500).json({ error: "Failed to enqueue task", detail: err.message });
  }
});

// ─── POST /schedule ───────────────────────────────────────────────────────────
app.post("/schedule", async (req, res) => {
  // Convenience wrapper — identical to /enqueue but scheduleDelaySeconds is required
  const schema = enqueueSchema.keys({
    scheduleDelaySeconds: Joi.number().integer().min(1).required(),
  });

  const { error, value } = schema.validate(req.body);
  if (error) return res.status(400).json({ error: error.details[0].message });

  req.body = value;
  return app.handle(Object.assign(req, { url: "/enqueue", path: "/enqueue" }), res);
});

// ─── GET /status/:taskId ──────────────────────────────────────────────────────
app.get("/status/:taskId", async (req, res) => {
  try {
    const doc = await firestore.collection("tasks").doc(req.params.taskId).get();
    if (!doc.exists) {
      const dlq = await firestore.collection("dead_letter_queue").doc(req.params.taskId).get();
      if (dlq.exists) return res.json({ ...dlq.data(), location: "dead_letter_queue" });
      return res.status(404).json({ error: "Task not found" });
    }
    return res.json(doc.data());
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// ─── GET /metrics ─────────────────────────────────────────────────────────────
app.get("/metrics", async (req, res) => {
  try {
    const [enqueue, overflow, processing] = await Promise.all([
      firestore.collection("metrics").doc("enqueue").get(),
      firestore.collection("metrics").doc("overflow").get(),
      firestore.collection("metrics").doc("processing").get(),
    ]);

    const queueSizes = await Promise.all(
      ["high", "medium", "low"].map(async (p) => ({ [p]: await getQueueSize(p) }))
    );

    return res.json({
      enqueue: enqueue.exists ? enqueue.data() : {},
      overflow: overflow.exists ? overflow.data() : {},
      processing: processing.exists ? processing.data() : {},
      currentQueueSizes: Object.assign({}, ...queueSizes),
    });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// ─── GET /dead-letter ─────────────────────────────────────────────────────────
app.get("/dead-letter", async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 50;
    const snapshot = await firestore
      .collection("dead_letter_queue")
      .orderBy("overflowAt", "desc")
      .limit(limit)
      .get();

    const tasks = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
    return res.json({ count: tasks.length, tasks });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// ─── POST /dead-letter/:taskId/requeue ───────────────────────────────────────
app.post("/dead-letter/:taskId/requeue", async (req, res) => {
  try {
    const dlqDoc = await firestore.collection("dead_letter_queue").doc(req.params.taskId).get();
    if (!dlqDoc.exists) return res.status(404).json({ error: "Dead letter task not found" });

    const data = dlqDoc.data();
    // Re-use enqueue logic by calling the same internal path
    req.body = { taskType: data.taskType, priority: data.priority, payload: data.payload };
    await firestore.collection("dead_letter_queue").doc(req.params.taskId).update({ status: "requeued" });

    return app.handle(Object.assign(req, { url: "/enqueue", path: "/enqueue" }), res);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// ─── Health check ─────────────────────────────────────────────────────────────
app.get("/health", (_, res) => res.json({ status: "ok", ts: new Date().toISOString() }));

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => logger.info(`API listening on port ${PORT}`));

module.exports = app;
