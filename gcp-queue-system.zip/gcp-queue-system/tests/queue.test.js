/**
 * Test Suite — gcp-queue-system
 *
 * Run:  npm test
 *
 * Uses Jest + supertest (API) + sinon (stubs for GCP SDK calls)
 */

"use strict";

const request  = require("supertest");
const sinon    = require("sinon");
const { expect } = require("@jest/globals");

// ── We stub GCP clients before requiring the app ─────────────────────────────
const tasksClientStub = {
  createTask: sinon.stub().resolves([{ name: "projects/p/locations/l/queues/q/tasks/t1" }]),
  queuePath:  sinon.stub().returns("projects/p/locations/l/queues/high_priority_queue"),
};

const firestoreDocStub = {
  set:    sinon.stub().resolves(),
  update: sinon.stub().resolves(),
  get:    sinon.stub().resolves({ exists: false }),
};

const firestoreCollStub = {
  doc: sinon.stub().returns(firestoreDocStub),
  where: sinon.stub().returnsThis(),
  count: sinon.stub().returns({ get: sinon.stub().resolves({ data: () => ({ count: 0 }) }) }),
};

jest.mock("@google-cloud/tasks", () => ({
  CloudTasksClient: jest.fn(() => tasksClientStub),
}));

jest.mock("@google-cloud/firestore", () => ({
  Firestore: jest.fn(() => ({
    collection: jest.fn(() => firestoreCollStub),
  })),
  FieldValue: { serverTimestamp: jest.fn(), increment: jest.fn((n) => n) },
}));

const app = require("../api/index");

// ─────────────────────────────────────────────────────────────────────────────
describe("POST /enqueue", () => {
  beforeEach(() => sinon.resetHistory());

  test("should enqueue a valid high-priority email task", async () => {
    const res = await request(app)
      .post("/enqueue")
      .send({
        taskType: "email",
        priority: "high",
        payload: { to: "user@example.com", subject: "Hello", body: "World" },
      });

    expect(res.status).toBe(201);
    expect(res.body).toHaveProperty("taskId");
    expect(res.body.status).toBe("queued");
    expect(res.body.priority).toBe("high");
  });

  test("should default priority to medium when not specified", async () => {
    const res = await request(app)
      .post("/enqueue")
      .send({ taskType: "sms", payload: { to: "+1234567890", message: "Hi" } });

    expect(res.status).toBe(201);
    expect(res.body.priority).toBe("medium");
  });

  test("should reject unknown taskType", async () => {
    const res = await request(app)
      .post("/enqueue")
      .send({ taskType: "unknown_type", priority: "low", payload: {} });

    expect(res.status).toBe(400);
    expect(res.body).toHaveProperty("error");
  });

  test("should reject missing payload", async () => {
    const res = await request(app)
      .post("/enqueue")
      .send({ taskType: "email", priority: "high" });

    expect(res.status).toBe(400);
  });

  test("should respect idempotency key on duplicate", async () => {
    firestoreDocStub.get.resolves({ exists: true, data: () => ({ status: "pending" }) });

    const res = await request(app)
      .post("/enqueue")
      .send({
        taskType: "webhook",
        priority: "medium",
        payload: { url: "https://example.com/hook" },
        idempotencyKey: "idem-abc-123",
      });

    expect(res.status).toBe(200);
    expect(res.body.idempotent).toBe(true);
    expect(res.body.status).toBe("already_queued");

    // Reset for subsequent tests
    firestoreDocStub.get.resolves({ exists: false });
  });

  test("should overflow to dead letter when queue is full", async () => {
    // Simulate queue at max capacity
    firestoreCollStub.count.returns({
      get: sinon.stub().resolves({ data: () => ({ count: 500 }) }), // HIGH max = 500
    });

    const res = await request(app)
      .post("/enqueue")
      .send({ taskType: "email", priority: "high", payload: { to: "x@x.com", subject: "s" } });

    expect(res.status).toBe(202);
    expect(res.body.dead_letter).toBe(true);

    // Restore
    firestoreCollStub.count.returns({
      get: sinon.stub().resolves({ data: () => ({ count: 0 }) }),
    });
  });
});

// ─────────────────────────────────────────────────────────────────────────────
describe("Worker handlers", () => {
  const handlers = require("../worker/handlers");

  test("email handler returns sent:true", async () => {
    const result = await handlers.email(
      { to: "a@b.com", subject: "Test", body: "Hi" },
      { taskId: "t1", attempt: 0 }
    );
    expect(result.sent).toBe(true);
    expect(result.to).toBe("a@b.com");
  });

  test("email handler throws on missing 'to'", async () => {
    await expect(
      handlers.email({ subject: "No recipient" }, { taskId: "t2", attempt: 0 })
    ).rejects.toThrow("'to' and 'subject' are required");
  });

  test("sms handler returns sent:true", async () => {
    const result = await handlers.sms({ to: "+1111111111", message: "Hey" }, { taskId: "t3" });
    expect(result.sent).toBe(true);
  });

  test("data_processing handler returns processed:true", async () => {
    const result = await handlers.data_processing(
      { datasetId: "ds1", operation: "aggregate" },
      { taskId: "t4" }
    );
    expect(result.processed).toBe(true);
  });

  test("report_generation handler returns generated:true", async () => {
    const result = await handlers.report_generation(
      { reportType: "monthly", format: "pdf" },
      { taskId: "t5" }
    );
    expect(result.generated).toBe(true);
    expect(result.url).toContain("t5");
  });

  test("image_resize handler returns variants", async () => {
    const result = await handlers.image_resize(
      { sourceUrl: "gs://bucket/img.jpg", widths: [640, 1280] },
      { taskId: "t6" }
    );
    expect(result.variants).toHaveLength(2);
    expect(result.variants[0].width).toBe(640);
  });

  test("unknown handler throws", async () => {
    const handler = handlers["nonexistent"];
    expect(handler).toBeUndefined();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
describe("GET /health", () => {
  test("returns 200 ok", async () => {
    const res = await request(app).get("/health");
    expect(res.status).toBe(200);
    expect(res.body.status).toBe("ok");
  });
});

// ─────────────────────────────────────────────────────────────────────────────
describe("Scheduler module", () => {
  const { scheduleDelayed } = require("../scheduler/index");

  test("scheduleDelayed throws for past dates", async () => {
    await expect(
      scheduleDelayed({
        taskType: "email",
        priority: "low",
        payload: {},
        runAt: new Date(Date.now() - 5000),
      })
    ).rejects.toThrow("runAt must be in the future");
  });

  test("scheduleDelayed returns taskId and delaySeconds", async () => {
    const future = new Date(Date.now() + 60000); // 60s from now
    const result = await scheduleDelayed({
      taskType: "report_generation",
      priority: "low",
      payload: { reportType: "weekly" },
      runAt: future,
    });
    expect(result).toHaveProperty("taskId");
    expect(result.delaySeconds).toBeGreaterThanOrEqual(59);
  });
});
