#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# deploy.sh  —  Full GCP deployment for the async queue system
#
# Usage:
#   chmod +x scripts/deploy.sh
#   GCP_PROJECT_ID=my-project ./scripts/deploy.sh
#
# Requirements: gcloud CLI authenticated, billing enabled, APIs enabled (below)
# ─────────────────────────────────────────────────────────────────────────────

set -euo pipefail

# ── Config ────────────────────────────────────────────────────────────────────
PROJECT_ID="${GCP_PROJECT_ID:?Set GCP_PROJECT_ID}"
REGION="${GCP_REGION:-us-central1}"
API_SERVICE="queue-api"
WORKER_FUNCTION="process-task"
METRICS_FUNCTION="metrics-export"
SA_API="queue-api-sa"
SA_WORKER="queue-worker-sa"
SA_SCHEDULER="queue-scheduler-sa"

echo "▶ Deploying to project: $PROJECT_ID  region: $REGION"

# ── Enable required GCP APIs ─────────────────────────────────────────────────
echo "▶ Enabling APIs..."
gcloud services enable \
  cloudtasks.googleapis.com \
  cloudfunctions.googleapis.com \
  cloudscheduler.googleapis.com \
  firestore.googleapis.com \
  cloudmonitoring.googleapis.com \
  run.googleapis.com \
  cloudbuild.googleapis.com \
  --project="$PROJECT_ID" --quiet

# ── Create service accounts ───────────────────────────────────────────────────
echo "▶ Creating service accounts..."
for SA in $SA_API $SA_WORKER $SA_SCHEDULER; do
  gcloud iam service-accounts create "$SA" \
    --display-name="$SA" \
    --project="$PROJECT_ID" 2>/dev/null || true
done

# Grant roles
gcloud projects add-iam-policy-binding "$PROJECT_ID" \
  --member="serviceAccount:${SA_API}@${PROJECT_ID}.iam.gserviceaccount.com" \
  --role="roles/cloudtasks.enqueuer" --quiet

gcloud projects add-iam-policy-binding "$PROJECT_ID" \
  --member="serviceAccount:${SA_API}@${PROJECT_ID}.iam.gserviceaccount.com" \
  --role="roles/datastore.user" --quiet

gcloud projects add-iam-policy-binding "$PROJECT_ID" \
  --member="serviceAccount:${SA_WORKER}@${PROJECT_ID}.iam.gserviceaccount.com" \
  --role="roles/datastore.user" --quiet

gcloud projects add-iam-policy-binding "$PROJECT_ID" \
  --member="serviceAccount:${SA_WORKER}@${PROJECT_ID}.iam.gserviceaccount.com" \
  --role="roles/monitoring.metricWriter" --quiet

gcloud projects add-iam-policy-binding "$PROJECT_ID" \
  --member="serviceAccount:${SA_SCHEDULER}@${PROJECT_ID}.iam.gserviceaccount.com" \
  --role="roles/cloudscheduler.jobRunner" --quiet

# ── Create Cloud Tasks queues ─────────────────────────────────────────────────
echo "▶ Creating Cloud Tasks queues..."
for QUEUE in high_priority_queue medium_priority_queue low_priority_queue dead_letter_queue; do
  gcloud tasks queues create "$QUEUE" \
    --location="$REGION" \
    --project="$PROJECT_ID" 2>/dev/null || true
done

# Apply full queue config from YAML
gcloud tasks queues import config/queues.yaml \
  --location="$REGION" \
  --project="$PROJECT_ID"

echo "  ✓ Queues configured"

# ── Create Firestore database ─────────────────────────────────────────────────
echo "▶ Ensuring Firestore database exists..."
gcloud firestore databases create \
  --location="$REGION" \
  --project="$PROJECT_ID" 2>/dev/null || true

# ── Deploy Worker Cloud Function ──────────────────────────────────────────────
echo "▶ Deploying worker Cloud Function..."
gcloud functions deploy "$WORKER_FUNCTION" \
  --gen2 \
  --runtime=nodejs20 \
  --region="$REGION" \
  --source=. \
  --entry-point=processTask \
  --trigger-http \
  --no-allow-unauthenticated \
  --service-account="${SA_WORKER}@${PROJECT_ID}.iam.gserviceaccount.com" \
  --set-env-vars="GCP_PROJECT_ID=${PROJECT_ID},GCP_LOCATION=${REGION}" \
  --min-instances=1 \
  --max-instances=100 \
  --concurrency=80 \
  --memory=512Mi \
  --timeout=300s \
  --project="$PROJECT_ID"

WORKER_URL=$(gcloud functions describe "$WORKER_FUNCTION" \
  --gen2 --region="$REGION" --project="$PROJECT_ID" \
  --format="value(serviceConfig.uri)")
echo "  ✓ Worker URL: $WORKER_URL"

# ── Deploy Metrics Export Cloud Function ─────────────────────────────────────
echo "▶ Deploying metrics export Cloud Function..."
gcloud functions deploy "$METRICS_FUNCTION" \
  --gen2 \
  --runtime=nodejs20 \
  --region="$REGION" \
  --source=. \
  --entry-point=metricsExport \
  --trigger-http \
  --no-allow-unauthenticated \
  --service-account="${SA_WORKER}@${PROJECT_ID}.iam.gserviceaccount.com" \
  --set-env-vars="GCP_PROJECT_ID=${PROJECT_ID},GCP_LOCATION=${REGION}" \
  --memory=256Mi \
  --project="$PROJECT_ID"

# ── Deploy API to Cloud Run ───────────────────────────────────────────────────
echo "▶ Deploying API to Cloud Run..."
gcloud run deploy "$API_SERVICE" \
  --source=. \
  --region="$REGION" \
  --service-account="${SA_API}@${PROJECT_ID}.iam.gserviceaccount.com" \
  --set-env-vars="GCP_PROJECT_ID=${PROJECT_ID},GCP_LOCATION=${REGION},SERVICE_URL=PLACEHOLDER,WORKER_SERVICE_ACCOUNT=${SA_WORKER}@${PROJECT_ID}.iam.gserviceaccount.com" \
  --allow-unauthenticated \
  --min-instances=1 \
  --max-instances=20 \
  --project="$PROJECT_ID" \
  --quiet

API_URL=$(gcloud run services describe "$API_SERVICE" \
  --region="$REGION" \
  --project="$PROJECT_ID" \
  --format="value(status.url)")
echo "  ✓ API URL: $API_URL"

# Patch SERVICE_URL now that we know it
gcloud run services update "$API_SERVICE" \
  --region="$REGION" \
  --project="$PROJECT_ID" \
  --set-env-vars="SERVICE_URL=${WORKER_URL}" \
  --quiet

# ── Register Cloud Scheduler cron for metrics export ─────────────────────────
METRICS_URL=$(gcloud functions describe "$METRICS_FUNCTION" \
  --gen2 --region="$REGION" --project="$PROJECT_ID" \
  --format="value(serviceConfig.uri)")

echo "▶ Setting up metrics cron job..."
gcloud scheduler jobs create http metrics-export-cron \
  --location="$REGION" \
  --schedule="* * * * *" \
  --uri="$METRICS_URL" \
  --http-method=GET \
  --oidc-service-account-email="${SA_SCHEDULER}@${PROJECT_ID}.iam.gserviceaccount.com" \
  --project="$PROJECT_ID" 2>/dev/null || \
gcloud scheduler jobs update http metrics-export-cron \
  --location="$REGION" \
  --schedule="* * * * *" \
  --uri="$METRICS_URL" \
  --project="$PROJECT_ID"

echo ""
echo "═══════════════════════════════════════════════════"
echo "  ✅  Deployment complete!"
echo "───────────────────────────────────────────────────"
echo "  API endpoint : $API_URL"
echo "  Worker       : $WORKER_URL"
echo "  Metrics      : $METRICS_URL"
echo "═══════════════════════════════════════════════════"
